<?
	require_once($globvars['local_root']."siteedit/filemanager/config/accesscontrol.php");
	
	$group = getUserConfiguration();
	if(file_exists($globvars['local_root']."siteedit/filemanager/config/useraccesscontrol/".$group."/config.php"))
		require_once($globvars['local_root']."siteedit/filemanager/config/useraccesscontrol/".$group."/config.php");
?>