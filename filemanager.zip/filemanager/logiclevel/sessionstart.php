<?
if(!session_is_registered("files_to_copy")) session_register("files_to_copy");
if(!session_is_registered("files_to_cut")) session_register("files_to_cut");

?>
