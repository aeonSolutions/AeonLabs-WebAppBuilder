<? 
require_once($globvars['local_root']."filemanager/config/config.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
		"http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<title>File List</title>
	<link href="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/styles/reset.css" rel="stylesheet" />
	<link href="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/styles/tree.css" rel="stylesheet" />
	<link href="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/styles/tree-lines.css" rel="stylesheet" />
	<link href="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/styles/dir-tree.css" rel="stylesheet" />
	<link href="<?=$globvars['site_path'];?>/filemanager/interfacelevel/css/loading.css" rel="stylesheet" />
	<style>
	#loadingbar {left:15%;}
	</style>
	<link href="<?=$globvars['site_path'];?>/filemanager/interfacelevel/css/dirlist.css" rel="stylesheet" />
	<script language="javascript" type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/jscripts/preloadimages.js"></script>
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/jscripts/dirlist.js"></script>
	
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/scripts/ajax.js"></script>
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/scripts/tree.js"></script>
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/scripts/tree_creation.js"></script>
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/scripts/tree_update.js"></script>
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/scripts/loadConfiguration.js"></script>
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/scripts/functions.js"></script>
	<script language="javascript"  type="text/javascript" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/scripts/tree_functions.js"></script>
	<script>
		var fileConfigURL = '<?=$globvars['site_path'];?>/filemanager/config/config_dirlist.xml';
		var fileDataURL = '<?=$globvars['site_path'];?>/filemanager/logiclevel/dirlist_ll.php?type=dirlist';
		var mainTreeDivID = 'tree';
		
		var root_path = '<?=$globvars['site']['directory'];?>';
	</script>
</head>

<body onLoad="MM_preloadImages('<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/themes/dir/windows/folder_open.gif','<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/img/plus.gif','<?=$globvars['site_path'];?>/filemanager/interfacelevel/tree/img/minus.gif');">
	<div id="folders">
		<img id="dotimg" src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/images/back_li_dot.png"/>
		<label>Folders</label>
	</div>
	<div id="divroot">
		<img src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/images/minus.gif" id="minusroot"> 
		<img src="<?=$globvars['site_path'];?>/filemanager/interfacelevel/images/root.gif" id="imgroot"> 
		<a id="aroot" href="#path=<? echo $CONFIG['root_path_name'];?>" onclick="goToPath('');selectedLabelOfLi('labelroot');"> 
			<label id="labelroot"><? echo $CONFIG['root_path_name'];?></label>
		</a>
	</div>
	<div id="divrootline"></div>
	<div id="tree">
<?
	require_once($globvars['local_root']."filemanager/interfacelevel/tree/phpcode/HtmlTree.php"); 
	$base_url = "http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
	$html_tree = new HtmlTree($globvars['site_path']."/filemanager/config/config_dirlist.xml",$globvars['site_path']."/filemanager/logiclevel/dirlist_ll.php?type=dirlist");
	$html_tree->createTreeByGetMethod();
	$html_tree->designTree();
?>
	</div>
</body>

</html>