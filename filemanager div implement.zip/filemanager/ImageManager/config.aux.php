<?
class CONFIGIMAGEMANAGER {

	function getTmpImgEditor() {
		return '.tmpimgxinhaeditor_';
	}
}
?>