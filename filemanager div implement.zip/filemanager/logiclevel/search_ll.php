<?
if(empty($search_file_location)) $search_file_location = $path;
?>