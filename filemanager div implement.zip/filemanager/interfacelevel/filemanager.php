<?
?>

<script type="text/javascript">
	function insertURL(url) {
		return null;
	}
</script>
<style>
.row div.mleft{
	width:50%;
	border: 1px solid #FFCC00;
	background:#FFFFCC;
	padding:5px;
}
.row div.mright{
	width:50%;
	border: 1px solid #009900;
	background:#CCFF99;
	padding:5px;
}

</style>
<div class="dtable">
    <div class="row">
        <div class="dirlist">
        	<?php
			include($globvars['local_root'].'filemanager/interfacelevel/dirlist.php');
			?>
        </div>
        <div class="filelistmanager">
        	<?php
			include($globvars['local_root'].'filemanager/interfacelevel/filelistmanager.php');
			?>
		</div>
        <div class="preview">
        	<?php
			include($globvars['local_root'].'filemanager/interfacelevel/preview.php');
			?>
		</div>
    </div>
</div>


